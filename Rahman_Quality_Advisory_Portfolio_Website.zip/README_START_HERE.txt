RAHMAN QUALITY ADVISORY — RESPONSIVE PORTFOLIO WEBSITE
=====================================================

WHAT YOU RECEIVED
- index.html: Complete responsive one-page portfolio. CSS and JavaScript are included.
- assets/favicon.svg: Website icon.
- assets/sample-portfolio-fictional.pdf: Downloadable, explicitly fictional sample portfolio.
- assets/fictional-spc-trend.png: Synthetic machining illustration.
- assets/fictional-spc-data.csv: Synthetic source demonstration dataset.

NO PAID SOFTWARE, WEBSITE BUILDER, DOMAIN OR API KEY REQUIRED TO TEST.

OPEN THE WEBSITE ON WINDOWS
1) Extract all ZIP files to a single folder.
2) Double-click index.html in File Explorer.
3) Chrome, Edge or another browser will show the responsive page.
4) Keep the assets folder beside index.html so PDF downloads and images work.

CRITICAL: ADD YOUR CONTACT DETAILS BEFORE PUBLISHING
1) Open index.html with Notepad, VS Code or another text editor.
2) Press Ctrl+F and search for: const SITE_CONFIG
3) Set email: "your-actual-business-email@domain.com"
4) Optionally set linkedinUrl: "https://www.linkedin.com/in/your-profile/"
5) Save the file and refresh the browser.
6) Test the enquiry form by opening a draft email, not by assuming it has sent a message.

The contact form is deliberately a mailto draft, not a server submission.
It is not connected to a database, inbox or paid backend. Visitors still need
an email application to actually send the inquiry. The "Copy message" button
works as an alternative once fields are completed.

PUBLISH ON A FREE STATIC HOST
Choose any static hosting provider (e.g. GitHub Pages or Cloudflare Pages).
Upload/publish index.html together with the entire assets folder. Their
free-tier conditions and account requirements can change, so check current
terms before relying on a provider. A purchased custom domain is OPTIONAL.

SUGGESTED PRE-PUBLISH CHECKLIST
[ ] Confirm the brand name is available and you may use it.
[ ] Verify your employment contract permits independent consulting.
[ ] Replace site email with a functioning business email.
[ ] Add the correct LinkedIn profile URL.
[ ] Re-read service scope, prices, timelines and tax wording.
[ ] Confirm business invoicing, privacy and legal obligations.
[ ] Keep all sample portfolio figures labeled fictional/synthetic.
[ ] Do not imply prior paid projects, testimonials or proven client improvements.
[ ] Never publish employer/client drawings, complaints or confidential records.
[ ] Open every link and test the enquiry button on phone and desktop.
[ ] Test readability, accessibility and layout before sharing publicly.

SITE CONTENT AND LIMITATIONS
Brand: Rahman Quality Advisory — working name, not trademark-verified.
Services: 8D, PFMEA, SPC, MSA and complaint quality reviews.
Fees: ₹9,900 / ₹29,900 / ₹69,900 — introductory, adjustable, GST if applicable.
All demonstration cases are fictional and explicitly labeled.
No OEM/IATF certification or technical sign-off is claimed.
No client results, testimonials, licensing or credentials are invented.
No web analytics, third-party tracking scripts or external font dependencies.

Technical note: Mailto requires a configured browser/device email app. For a
future in-browser enquiry submission, you will need an authorized form backend
and an appropriate privacy notice, with potential free-tier limits.
